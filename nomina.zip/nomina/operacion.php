<?php

	$nombre = $_POST["nombre"];
	$dias = $_POST["dias"];
	$salario = $_POST["salario"];
	$deudas = $_POST["deudas"];
	$transporte = $_POST["transporte"];
	$pension = $salario * 4.5 / 100;
	$salud = $salario * 4.5 / 100;
	$total = ($dias * $salario) - $pension - $salud - $deudas + $transporte;

	echo "Nombre del Empleado: " . $nombre . "<br>";
	echo "Dias Trabajados: " . $dias . "<br>";
	echo "Salario por Dia: " . $salario . "<br>";
	echo "Deudas: " . $deudas . "<br>";
	echo "Pension: " . $pension . "<br>";
	echo "Salud: " . $salud . "<br>";
	echo "Aux transporte: " . $transporte . "<br>";
	echo "Neto Total: " . $total;

?>

